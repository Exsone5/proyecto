//  Base de Datos
const uñas = [
    { id: 1, nombre: "Manicura Francesa", precio: 20 },
    { id: 2, nombre: "Esmaltado Semipermanente", precio: 25 },
    { id: 3, nombre: "Esmaltado Permanente", precio: 30 },
    { id: 4, nombre: "Decoración de Uñas", precio: 35 },
]

const serviciosSeleccionados = []

//  Mostrar menú en el DOM
function mostrarMenuUñas() {
    const menuDiv = document.getElementById("menu")
    menuDiv.innerHTML = ""

    uñas.forEach(uña => {
        const div = document.createElement("div")
        div.className = "servicio"
        div.innerHTML = `
            ${uña.nombre} - $${uña.precio}
            <button onclick="seleccionarServicio(${uña.id})">Seleccionar</button>
        `
        menuDiv.appendChild(div)
    })
}

//  Seleccionar servicio
function seleccionarServicio(id) {
    const servicioSeleccionado = uñas.find(uña => uña.id === id)

    if (!servicioSeleccionado) {
        mostrarMensaje("❌ Servicio no encontrado.", "error")
        return
    }

    if (serviciosSeleccionados.some(s => s.id === servicioSeleccionado.id)) {
        mostrarMensaje("⚠️ Ya seleccionaste este servicio.", "error")
        return
    }

    serviciosSeleccionados.push(servicioSeleccionado)
    localStorage.setItem("serviciosSeleccionados", JSON.stringify(serviciosSeleccionados))
    mostrarResumen()
}

//  Calcular total
function calcularTotal(servicios) {
    return servicios.reduce((total, servicio) => total + servicio.precio, 0)
}

//  Mostrar resumen
function mostrarResumen() {
    const resumenDiv = document.getElementById("resumen")
    resumenDiv.innerHTML = "<h2>🧾 Resumen de tu compra:</h2>"

    serviciosSeleccionados.forEach((s, index) => {
        const p = document.createElement("p")
        p.innerHTML = `${s.nombre}: $${s.precio} 
            <button onclick="eliminarServicio(${index})">❌ Eliminar</button>`
        resumenDiv.appendChild(p)
    })

    const total = calcularTotal(serviciosSeleccionados)
    const totalP = document.createElement("p")
    totalP.innerHTML = `<strong>💸 Total: $${total}</strong>`
    resumenDiv.appendChild(totalP)
}

// Mostrar mensaje en pantalla
function mostrarMensaje(texto, tipo) {
    const resumenDiv = document.getElementById("resumen")
    const mensaje = document.createElement("p")
    mensaje.textContent = texto
    mensaje.style.color = tipo === "error" ? "red" : "green"
    resumenDiv.appendChild(mensaje)
}

// Inicializar simulador
document.addEventListener("DOMContentLoaded", () => {
    const guardados = JSON.parse(localStorage.getItem("serviciosSeleccionados")) || []
    serviciosSeleccionados.push(...guardados)
    mostrarMenuUñas()
    if (serviciosSeleccionados.length > 0) {
        mostrarResumen()
    }
})
//  Eliminar servicio
function eliminarServicio(index) {
    serviciosSeleccionados.splice(index, 1)
    localStorage.setItem("serviciosSeleccionados", JSON.stringify(serviciosSeleccionados))
    mostrarResumen()
}
