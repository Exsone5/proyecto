//  Base de Datos
let uñas = [];

const serviciosSeleccionados = []

//  Mostrar menú en el DOM
function mostrarMenuUñas() {
    const menuDiv = document.getElementById("menu")
    menuDiv.innerHTML = ""

    uñas.forEach(uña => {
        const div = document.createElement("div")
        div.className = "servicio"
        div.innerHTML = `
            ${uña.nombre} - $${uña.precio}
            <button onclick="seleccionarServicio(${uña.id})">Seleccionar</button>
        `
        menuDiv.appendChild(div)
    })
}

//  Seleccionar servicio
function seleccionarServicio(id) {
    const servicioSeleccionado = uñas.find(uña => uña.id === id)

    if (!servicioSeleccionado) {
        mostrarMensaje("❌ Servicio no encontrado.", "error")
        return
    }

    if (serviciosSeleccionados.some(s => s.id === servicioSeleccionado.id)) {
        mostrarMensaje("⚠️ Ya seleccionaste este servicio.", "error")
        return
    }

    serviciosSeleccionados.push(servicioSeleccionado)
    localStorage.setItem("serviciosSeleccionados", JSON.stringify(serviciosSeleccionados))
    mostrarResumen()
}

//  Calcular total
function calcularTotal(servicios) {
    return servicios.reduce((total, servicio) => total + servicio.precio, 0)
}

//  Mostrar resumen
function mostrarResumen() {
    const resumenDiv = document.getElementById("resumen")
    resumenDiv.innerHTML = "<h2>🧾 Resumen de tu compra:</h2>"

    serviciosSeleccionados.forEach((s, index) => {
        const p = document.createElement("p")
        p.innerHTML = `${s.nombre}: $${s.precio} 
            <button onclick="eliminarServicio(${index})">❌ Eliminar</button>`
        resumenDiv.appendChild(p)
    })

    const total = calcularTotal(serviciosSeleccionados)
    const totalP = document.createElement("p")
    totalP.innerHTML = `<strong>💸 Total: $${total}</strong>`
    resumenDiv.appendChild(totalP)
}

// Mostrar mensaje en pantalla
function mostrarMensaje(texto, tipo) {
    const resumenDiv = document.getElementById("resumen")
    const mensaje = document.createElement("p")
    mensaje.textContent = texto
    mensaje.style.color = tipo === "error" ? "red" : "green"
    resumenDiv.appendChild(mensaje)
}

// Inicializar simulador
document.addEventListener("DOMContentLoaded", () => {
  fetch("servicios.json")
    .then(res => res.json())
    .then(data => {
      uñas = data;
      const guardados = JSON.parse(localStorage.getItem("serviciosSeleccionados")) || [];
      serviciosSeleccionados.push(...guardados);
      mostrarMenuUñas();
      if (serviciosSeleccionados.length > 0) {
        mostrarResumen();
      }
    })
    .catch(error => {
      console.error("Error al cargar servicios:", error);
      mostrarMensaje("❌ No se pudieron cargar los servicios.", "error");
    });
})


//  Eliminar servicio
function eliminarServicio(index) {
    serviciosSeleccionados.splice(index, 1)
    localStorage.setItem("serviciosSeleccionados", JSON.stringify(serviciosSeleccionados))
    mostrarResumen()
}
function mostrarMensaje(texto, tipo) {
  Swal.fire({
    text: texto,
    icon: tipo, // "success", "error", "warning", "info", "question"
    confirmButtonText: "OK",
    timer: 2000,
    showConfirmButton: false
  });
}
function eliminarServicio(index) {
  Swal.fire({
    title: "¿Eliminar este servicio?",
    text: "Esta acción no se puede deshacer.",
    icon: "warning",
    showCancelButton: true,
    confirmButtonText: "Sí, eliminar",
    cancelButtonText: "Cancelar"
  }).then((result) => {
    if (result.isConfirmed) {
      serviciosSeleccionados.splice(index, 1);
      localStorage.setItem("serviciosSeleccionados", JSON.stringify(serviciosSeleccionados));
      mostrarResumen();
      mostrarMensaje("Servicio eliminado.", "success");
    }
  });
}
